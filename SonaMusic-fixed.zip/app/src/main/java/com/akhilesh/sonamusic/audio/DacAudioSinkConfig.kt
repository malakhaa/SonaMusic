package com.akhilesh.sonamusic.audio

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import androidx.annotation.OptIn
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.DefaultAudioSink

object DacAudioSinkConfig {

    @OptIn(UnstableApi::class)
    fun createAudiophileAudioSink(
        context: Context,
        vocalProcessor: AudioProcessor
    ): DefaultAudioSink {

        return DefaultAudioSink.Builder(context)
            .setAudioProcessors(arrayOf(vocalProcessor))
            .setEnableFloatOutput(true) // 32-bit floating point high dynamic range
            .setEnableAudioTrackPlaybackParams(false)
            .build()
    }

    fun isUsbAudioDevice(device: UsbDevice): Boolean {
        if (device.deviceClass == UsbConstants.USB_CLASS_AUDIO) return true
        for (i in 0 until device.interfaceCount) {
            if (device.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_AUDIO) return true
        }
        return false
    }

    fun getConnectedUsbDac(context: Context): UsbDevice? {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager ?: return null
        return usbManager.deviceList.values.firstOrNull { isUsbAudioDevice(it) }
    }
}
