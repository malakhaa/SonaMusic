package com.akhilesh.sonamusic.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/** Stereo 16-bit PCM mid/side processor: karaoke (remove centre) or vocal-focus (keep centre). */
@OptIn(UnstableApi::class)
class VocalIsolationAudioProcessor : BaseAudioProcessor() {

    enum class IsolationMode { OFF, REMOVE_VOCALS, ISOLATE_VOCALS }

    @Volatile
    private var currentMode = IsolationMode.OFF

    fun setMode(mode: IsolationMode) { currentMode = mode }
    fun getMode(): IsolationMode = currentMode

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // Only handle stereo 16-bit PCM; anything else passes through untouched.
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        val mode = currentMode

        if (mode == IsolationMode.OFF) {
            out.put(inputBuffer)
        } else {
            while (inputBuffer.remaining() >= 4) {
                val left = inputBuffer.getShort().toInt()
                val right = inputBuffer.getShort().toInt()
                val sample: Short = when (mode) {
                    IsolationMode.REMOVE_VOCALS -> clamp((left - right) * 0.5f)
                    IsolationMode.ISOLATE_VOCALS -> clamp((left + right) * 0.5f)
                    IsolationMode.OFF -> left.toShort()
                }
                out.putShort(sample)
                out.putShort(sample)
            }
            out.put(inputBuffer) // any trailing partial frame
        }
        out.flip()
    }

    private fun clamp(v: Float): Short = v.coerceIn(-32768f, 32767f).toInt().toShort()
}
