package com.akhilesh.sonamusic.hardware

import android.content.Context
import android.hardware.ConsumerIrManager

class BeztonIrManager(context: Context) {
    private val irManager: ConsumerIrManager? = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    companion object {
        const val CARRIER_FREQUENCY = 38000
        const val HEX_POWER = "00FF02FD"
        const val HEX_MUTE = "00FF22DD"
        const val HEX_VOL_UP = "00FF12ED"
        const val HEX_VOL_DOWN = "00FF1AE5"
        const val HEX_BASS_UP = "00FF32CD"
        const val HEX_BASS_DOWN = "00FF3AC5"
        const val HEX_TREBLE_UP = "00FF52AD"
        const val HEX_TREBLE_DOWN = "00FF5AA5"
        const val HEX_INPUT_51_SURROUND = "00FFAA55"
        const val HEX_SUBWOOFER_BOOST = "00FF728D"
    }

    fun transmitHex(hexCode: String): Boolean {
        if (irManager?.hasIrEmitter() != true) return false
        val pulses = hexToNecPulses(hexCode)
        irManager.transmit(CARRIER_FREQUENCY, pulses)
        return true
    }

    private fun hexToNecPulses(hexCode: String): IntArray {
        val code = hexCode.replace("0x", "").trim().toLong(16)
        val pulses = ArrayList<Int>()
        pulses.add(9000); pulses.add(4500)
        for (i in 31 downTo 0) {
            val bit = (code shr i) and 1L
            pulses.add(562)
            pulses.add(if (bit == 1L) 1687 else 562)
        }
        pulses.add(562)
        return pulses.toIntArray()
    }
}