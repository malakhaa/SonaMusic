package com.akhilesh.sonamusic.audio

import android.os.Build

/**
 * Process-wide bridge between the UI (ViewModel) and the playback service,
 * which both live in the same process.
 */
object AudioEngineHub {
    val vocalProcessor = VocalIsolationAudioProcessor()
    val bandFrequencies = floatArrayOf(31.25f, 62.5f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)

    private val gains = FloatArray(bandFrequencies.size)
    private var preAmp = 0f
    private var manager: DynamicsProcessingManager? = null

    @Synchronized
    fun attach(audioSessionId: Int) {
        releaseManager()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P || audioSessionId == 0) return
        try {
            val m = DynamicsProcessingManager(audioSessionId)
            m.setPreAmpGain(preAmp)
            for (i in gains.indices) m.setBandGain(i, gains[i])
            manager = m
        } catch (e: Exception) {
            manager = null
        }
    }

    @Synchronized
    fun setBandGain(index: Int, gainDb: Float) {
        if (index !in gains.indices) return
        gains[index] = gainDb
        try { manager?.setBandGain(index, gainDb) } catch (e: Exception) {}
    }

    @Synchronized
    fun setPreAmp(gainDb: Float) {
        preAmp = gainDb
        try { manager?.setPreAmpGain(gainDb) } catch (e: Exception) {}
    }

    @Synchronized
    fun releaseManager() {
        try { manager?.release() } catch (e: Exception) {}
        manager = null
    }
}
