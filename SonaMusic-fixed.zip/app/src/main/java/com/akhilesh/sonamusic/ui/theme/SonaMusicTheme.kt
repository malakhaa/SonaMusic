package com.akhilesh.sonamusic.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

val GoldHiRes = Color(0xFFFFD700)
val NeonCyan = Color(0xFF38BDF8)

@Composable
fun SonaMusicTheme(
    primaryColor: Color = GoldHiRes,
    secondaryColor: Color = NeonCyan,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = primaryColor,
            secondary = secondaryColor,
            background = Color(0xFF090D16),
            surface = Color(0xFF141E33),
            onPrimary = Color(0xFF090D16),
            onBackground = Color(0xFFE6EDF7),
            onSurface = Color(0xFFE6EDF7)
        ),
        content = content
    )
}

/** Translucent "glass" panel: tinted fill + thin light border. (No blur, so text stays sharp.) */
fun Modifier.glassmorphicSurface(
    shape: Shape = RoundedCornerShape(18.dp),
    backgroundColor: Color = Color(0x40141E33),
    borderColor: Color = Color(0x2EFFFFFF)
): Modifier = this
    .clip(shape)
    .background(backgroundColor)
    .border(1.dp, borderColor, shape)
