package com.akhilesh.sonamusic.audio

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.DynamicsProcessing.Config
import android.media.audiofx.DynamicsProcessing.EqBand
import android.os.Build
import androidx.annotation.RequiresApi

/** 10-band parametric pre-EQ + input gain on top of an ExoPlayer audio session (API 28+). */
@RequiresApi(Build.VERSION_CODES.P)
class DynamicsProcessingManager(audioSessionId: Int) {

    private var dynamicsProcessing: DynamicsProcessing? = null
    val bandFrequencies: FloatArray = AudioEngineHub.bandFrequencies

    init {
        val config = Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,                          // channels
            true, bandFrequencies.size, // pre-EQ
            false, 0,                   // MBC
            false, 0,                   // post-EQ
            false                       // limiter
        ).build()
        val dp = DynamicsProcessing(0, audioSessionId, config)
        dp.setEnabled(true)
        dynamicsProcessing = dp
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        val dp = dynamicsProcessing ?: return
        if (bandIndex !in bandFrequencies.indices) return
        val band = EqBand(true, bandFrequencies[bandIndex], gainDb.coerceIn(-12f, 12f))
        dp.setPreEqBandAllChannelsTo(bandIndex, band)
    }

    fun setPreAmpGain(gainDb: Float) {
        dynamicsProcessing?.setInputGainAllChannelsTo(gainDb.coerceIn(-12f, 12f))
    }

    fun release() {
        dynamicsProcessing?.release()
        dynamicsProcessing = null
    }
}
