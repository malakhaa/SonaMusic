package com.akhilesh.sonamusic

import android.app.Application

class SonaMusicApp : Application()
