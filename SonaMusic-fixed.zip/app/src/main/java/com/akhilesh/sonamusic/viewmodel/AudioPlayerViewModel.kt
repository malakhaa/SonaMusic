package com.akhilesh.sonamusic.viewmodel

import android.app.Application
import android.app.PendingIntent
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.hardware.ConsumerIrManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.palette.graphics.Palette
import com.akhilesh.sonamusic.audio.AudioEngineHub
import com.akhilesh.sonamusic.audio.DacAudioSinkConfig
import com.akhilesh.sonamusic.audio.VocalIsolationAudioProcessor.IsolationMode
import com.akhilesh.sonamusic.hardware.BeztonIrManager
import com.akhilesh.sonamusic.hardware.UsbSerialIrReceiver
import com.akhilesh.sonamusic.service.PlaybackService
import com.akhilesh.sonamusic.ui.theme.GoldHiRes
import com.akhilesh.sonamusic.ui.theme.NeonCyan
import com.google.common.util.concurrent.ListenableFuture
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri
)

class AudioPlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application

    // ---- Library ----
    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    // ---- Playback state ----
    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()
    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    // ---- Dynamic theme colours ----
    private val _primary = MutableStateFlow(GoldHiRes)
    val dynamicPrimaryColor: StateFlow<Color> = _primary.asStateFlow()
    private val _secondary = MutableStateFlow(NeonCyan)
    val dynamicSecondaryColor: StateFlow<Color> = _secondary.asStateFlow()

    // ---- DSP ----
    private val _vocalMode = MutableStateFlow(IsolationMode.OFF)
    val vocalMode: StateFlow<IsolationMode> = _vocalMode.asStateFlow()
    private val _eqGains = MutableStateFlow(List(AudioEngineHub.bandFrequencies.size) { 0f })
    val eqGains: StateFlow<List<Float>> = _eqGains.asStateFlow()
    private val _preAmp = MutableStateFlow(0f)
    val preAmp: StateFlow<Float> = _preAmp.asStateFlow()

    // ---- Hardware ----
    private val _dacName = MutableStateFlow<String?>(null)
    val dacName: StateFlow<String?> = _dacName.asStateFlow()
    private val _hasIrEmitter = MutableStateFlow(false)
    val hasIrEmitter: StateFlow<Boolean> = _hasIrEmitter.asStateFlow()
    private val _hardwareStatus = MutableStateFlow("Ready")
    val hardwareStatus: StateFlow<String> = _hardwareStatus.asStateFlow()
    private val _isLearning = MutableStateFlow(false)
    val isLearning: StateFlow<Boolean> = _isLearning.asStateFlow()
    private val _learnedCodes = MutableStateFlow<List<String>>(emptyList())
    val learnedCodes: StateFlow<List<String>> = _learnedCodes.asStateFlow()

    private var irManager: BeztonIrManager? = null
    private val usbIr = UsbSerialIrReceiver(app)

    // ---- Media3 controller ----
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var queueLoaded = false
    private var colorJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateCurrent(mediaItem)
        }
    }

    init {
        _dacName.value = DacAudioSinkConfig.getConnectedUsbDac(app)?.let { it.productName ?: "USB DAC" }
        connectController()

        viewModelScope.launch {
            while (true) {
                controller?.let { c ->
                    _positionMs.value = c.currentPosition.coerceAtLeast(0L)
                    val d = c.duration
                    _durationMs.value = if (d > 0) d else 0L
                }
                delay(500)
            }
        }
        viewModelScope.launch {
            usbIr.learnedHexEvents.collect { code ->
                _learnedCodes.value = (listOf(code) + _learnedCodes.value).distinct().take(20)
            }
        }
    }

    private fun connectController() {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                _isPlaying.value = c.isPlaying
                updateCurrent(c.currentMediaItem)
            } catch (e: Exception) {
                _hardwareStatus.value = "Player connection failed: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(app))
    }

    // ---------------------------------------------------------------- Library

    fun loadLibrary() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { queryTracks() }
            _tracks.value = list
            queueLoaded = false
        }
    }

    private fun queryTracks(): List<Track> {
        val out = ArrayList<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            app.contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    out.add(
                        Track(
                            id = id,
                            title = c.getString(titleCol) ?: "Unknown title",
                            artist = c.getString(artistCol) ?: "Unknown artist",
                            album = c.getString(albumCol) ?: "Unknown album",
                            durationMs = c.getLong(durCol),
                            uri = ContentUris.withAppendedId(collection, id)
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            // Permission not granted yet.
        }
        return out
    }

    // --------------------------------------------------------------- Playback

    private fun toMediaItem(t: Track): MediaItem =
        MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .build()
            )
            .build()

    fun playTrack(index: Int) {
        val c = controller ?: return
        val list = _tracks.value
        if (index !in list.indices) return
        if (!queueLoaded) {
            c.setMediaItems(list.map { toMediaItem(it) }, index, 0L)
            c.prepare()
            queueLoaded = true
        } else {
            c.seekTo(index, 0L)
        }
        c.play()
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playTrack(0)
        } else if (c.isPlaying) {
            c.pause()
        } else {
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs) }

    private fun updateCurrent(item: MediaItem?) {
        val track = _tracks.value.firstOrNull { it.id.toString() == item?.mediaId }
        _currentTrack.value = track
        updateColors(track)
        _positionMs.value = 0L
    }

    // ----------------------------------------------------------- Album colours

    private fun updateColors(track: Track?) {
        colorJob?.cancel()
        colorJob = viewModelScope.launch {
            val colors = if (track == null) null else withContext(Dispatchers.Default) { extractColors(track.uri) }
            _primary.value = colors?.first ?: GoldHiRes
            _secondary.value = colors?.second ?: NeonCyan
        }
    }

    private fun extractColors(uri: Uri): Pair<Color, Color>? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(app, uri)
            val bytes = retriever.embeddedPicture
            if (bytes == null) {
                null
            } else {
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap == null) {
                    null
                } else {
                    val palette = Palette.from(bitmap).maximumColorCount(16).generate()
                    val primary = palette.getLightVibrantColor(palette.getVibrantColor(GoldHiRes.toArgb()))
                    val secondary = palette.getLightMutedColor(palette.getMutedColor(NeonCyan.toArgb()))
                    Pair(Color(primary), Color(secondary))
                }
            }
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (e: Exception) {}
        }
    }

    // -------------------------------------------------------------------- DSP

    fun setVocalMode(mode: IsolationMode) {
        AudioEngineHub.vocalProcessor.setMode(mode)
        _vocalMode.value = mode
    }

    fun setEqBand(index: Int, gainDb: Float) {
        AudioEngineHub.setBandGain(index, gainDb)
        _eqGains.value = _eqGains.value.toMutableList().also { it[index] = gainDb }
    }

    fun setPreAmp(gainDb: Float) {
        AudioEngineHub.setPreAmp(gainDb)
        _preAmp.value = gainDb
    }

    fun resetEq() {
        for (i in _eqGains.value.indices) AudioEngineHub.setBandGain(i, 0f)
        AudioEngineHub.setPreAmp(0f)
        _eqGains.value = List(_eqGains.value.size) { 0f }
        _preAmp.value = 0f
    }

    // --------------------------------------------------------------- Hardware

    fun setConsumerIrManager(manager: ConsumerIrManager?) {
        _hasIrEmitter.value = manager?.hasIrEmitter() == true
        irManager = BeztonIrManager(app)
    }

    fun sendIr(hex: String) {
        val ok = try {
            irManager?.transmitHex(hex) == true
        } catch (e: Exception) {
            false
        }
        _hardwareStatus.value = if (ok) "Sent IR code $hex" else "No IR blaster available (or invalid code)"
    }

    fun onUsbDeviceAttached(device: UsbDevice) {
        if (DacAudioSinkConfig.isUsbAudioDevice(device)) {
            _dacName.value = device.productName ?: "USB DAC"
            _hardwareStatus.value = "USB DAC connected"
        }
    }

    fun onUsbDeviceDetached(device: UsbDevice) {
        if (DacAudioSinkConfig.isUsbAudioDevice(device)) {
            _dacName.value = DacAudioSinkConfig.getConnectedUsbDac(app)?.let { it.productName ?: "USB DAC" }
            _hardwareStatus.value = "USB DAC disconnected"
        }
    }

    fun toggleIrLearning() {
        if (_isLearning.value) {
            usbIr.stopLearning()
            _isLearning.value = false
            _hardwareStatus.value = "Learning stopped"
            return
        }
        val usbManager = app.getSystemService(Context.USB_SERVICE) as UsbManager
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            _hardwareStatus.value = "No USB serial IR adapter found"
            return
        }
        val device = drivers[0].device
        if (!usbManager.hasPermission(device)) {
            val pi = PendingIntent.getBroadcast(
                app, 0,
                Intent("com.akhilesh.sonamusic.USB_PERMISSION").setPackage(app.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(device, pi)
            _hardwareStatus.value = "Allow USB access, then tap Learn again"
            return
        }
        val started = try { usbIr.startLearning() } catch (e: Exception) { false }
        _isLearning.value = started
        _hardwareStatus.value = if (started) "Listening - press a remote button" else "Could not open USB adapter"
    }

    override fun onCleared() {
        usbIr.stopLearning()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onCleared()
    }
}
