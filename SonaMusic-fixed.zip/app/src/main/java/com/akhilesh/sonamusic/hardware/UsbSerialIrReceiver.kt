package com.akhilesh.sonamusic.hardware

import android.content.Context
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.nio.charset.StandardCharsets

class UsbSerialIrReceiver(context: Context) : SerialInputOutputManager.Listener {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private var serialPort: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private val _learnedHexEvents = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val learnedHexEvents: SharedFlow<String> = _learnedHexEvents.asSharedFlow()

    fun startLearning(): Boolean {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) return false
        val connection = usbManager.openDevice(drivers[0].device) ?: return false
        val port = drivers[0].ports[0]
        port.open(connection)
        port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        serialPort = port
        val manager = SerialInputOutputManager(port, this)
        manager.start()
        ioManager = manager
        return true
    }

    override fun onNewData(data: ByteArray?) {
        val bytes = data ?: return
        val text = String(bytes, StandardCharsets.UTF_8)
        val match = Regex("(?i)([0-9A-F]{8})").find(text)
        match?.let { _learnedHexEvents.tryEmit(it.value.uppercase()) }
    }

    override fun onRunError(e: Exception?) {}

    fun stopLearning() {
        try { ioManager?.stop() } catch (e: Exception) {}
        ioManager = null
        try { serialPort?.close() } catch (e: Exception) {}
        serialPort = null
    }
}
