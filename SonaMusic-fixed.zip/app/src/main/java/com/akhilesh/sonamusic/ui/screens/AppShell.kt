package com.akhilesh.sonamusic.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.akhilesh.sonamusic.ui.components.MiniPlayer
import com.akhilesh.sonamusic.viewmodel.AudioPlayerViewModel

@Composable
fun SonaMusicAppShell(viewModel: AudioPlayerViewModel) {
    val context = LocalContext.current
    val primary by viewModel.dynamicPrimaryColor.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.loadLibrary() }

    LaunchedEffect(Unit) {
        viewModel.loadLibrary()
        val missing = permissions.any {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing) launcher.launch(permissions)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF090D16), primary.copy(alpha = 0.22f), Color(0xFF090D16))
                )
            )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            bottomBar = {
                Column {
                    MiniPlayer(viewModel = viewModel, onClick = { tab = 1 })
                    NavigationBar(containerColor = Color(0xE60B1220)) {
                        NavItem(0, tab, "Library", Icons.Filled.LibraryMusic) { tab = it }
                        NavItem(1, tab, "Playing", Icons.Filled.MusicNote) { tab = it }
                        NavItem(2, tab, "EQ", Icons.Filled.GraphicEq) { tab = it }
                        NavItem(3, tab, "Hardware", Icons.Filled.Usb) { tab = it }
                    }
                }
            }
        ) { padding ->
            val contentModifier = Modifier.padding(padding)
            when (tab) {
                0 -> LibraryScreen(viewModel, onPlayed = { tab = 1 }, modifier = contentModifier)
                1 -> NowPlayingScreen(viewModel, modifier = contentModifier)
                2 -> EqualizerScreen(viewModel, modifier = contentModifier)
                else -> HardwareScreen(viewModel, modifier = contentModifier)
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.NavItem(
    index: Int,
    selectedIndex: Int,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onSelect: (Int) -> Unit
) {
    NavigationBarItem(
        selected = selectedIndex == index,
        onClick = { onSelect(index) },
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}
