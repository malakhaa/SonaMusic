package com.akhilesh.sonamusic.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.akhilesh.sonamusic.hardware.BeztonIrManager
import com.akhilesh.sonamusic.ui.components.GlassCard
import com.akhilesh.sonamusic.viewmodel.AudioPlayerViewModel

private val REMOTE_BUTTONS = listOf(
    "Power" to BeztonIrManager.HEX_POWER,
    "Mute" to BeztonIrManager.HEX_MUTE,
    "Vol +" to BeztonIrManager.HEX_VOL_UP,
    "Vol -" to BeztonIrManager.HEX_VOL_DOWN,
    "Bass +" to BeztonIrManager.HEX_BASS_UP,
    "Bass -" to BeztonIrManager.HEX_BASS_DOWN,
    "Treble +" to BeztonIrManager.HEX_TREBLE_UP,
    "Treble -" to BeztonIrManager.HEX_TREBLE_DOWN,
    "5.1 Surround" to BeztonIrManager.HEX_INPUT_51_SURROUND,
    "Sub Boost" to BeztonIrManager.HEX_SUBWOOFER_BOOST
)

@Composable
fun HardwareScreen(viewModel: AudioPlayerViewModel, modifier: Modifier = Modifier) {
    val dac by viewModel.dacName.collectAsState()
    val hasIr by viewModel.hasIrEmitter.collectAsState()
    val status by viewModel.hardwareStatus.collectAsState()
    val learning by viewModel.isLearning.collectAsState()
    val learned by viewModel.learnedCodes.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Hardware", style = MaterialTheme.typography.headlineMedium)

        GlassCard {
            Text("USB DAC", style = MaterialTheme.typography.titleMedium)
            Text(dac ?: "No USB DAC detected")
            Text(
                if (hasIr) "IR blaster: available" else "IR blaster: not found on this phone",
                style = MaterialTheme.typography.bodySmall
            )
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        }

        GlassCard {
            Text("Bezton remote (IR)", style = MaterialTheme.typography.titleMedium)
            REMOTE_BUTTONS.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { (name, hex) ->
                        Button(onClick = { viewModel.sendIr(hex) }, modifier = Modifier.weight(1f)) {
                            Text(name)
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        GlassCard {
            Text("IR learning (USB serial adapter)", style = MaterialTheme.typography.titleMedium)
            Button(onClick = { viewModel.toggleIrLearning() }, modifier = Modifier.fillMaxWidth()) {
                Text(if (learning) "Stop learning" else "Start learning")
            }
            if (learned.isEmpty()) {
                Text("No codes learned yet.", style = MaterialTheme.typography.bodySmall)
            }
            learned.forEach { code ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(code, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { viewModel.sendIr(code) }) { Text("Send") }
                }
            }
        }
    }
}
