package com.akhilesh.sonamusic.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.akhilesh.sonamusic.ui.components.GlassCard
import com.akhilesh.sonamusic.viewmodel.AudioPlayerViewModel
import java.util.Locale

private val BAND_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

@Composable
fun EqualizerScreen(viewModel: AudioPlayerViewModel, modifier: Modifier = Modifier) {
    val gains by viewModel.eqGains.collectAsState()
    val preAmp by viewModel.preAmp.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Equalizer", style = MaterialTheme.typography.headlineMedium)
        Text(
            "10-band parametric EQ (Android DynamicsProcessing). Play a song first so the effect can attach.",
            style = MaterialTheme.typography.bodySmall
        )

        GlassCard {
            EqRow(label = "Pre-amp", value = preAmp, onChange = { viewModel.setPreAmp(it) })
            gains.forEachIndexed { index, gain ->
                EqRow(
                    label = BAND_LABELS.getOrElse(index) { "" } + " Hz",
                    value = gain,
                    onChange = { viewModel.setEqBand(index, it) }
                )
            }
        }

        OutlinedButton(onClick = { viewModel.resetEq() }, modifier = Modifier.fillMaxWidth()) {
            Text("Reset to flat")
        }
    }
}

@Composable
private fun EqRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(72.dp), style = MaterialTheme.typography.labelMedium)
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = -12f..12f,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = String.format(Locale.US, "%+.1f", value),
            modifier = Modifier.width(44.dp),
            style = MaterialTheme.typography.labelMedium
        )
    }
}
