package com.akhilesh.sonamusic

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.ConsumerIrManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.akhilesh.sonamusic.ui.screens.SonaMusicAppShell
import com.akhilesh.sonamusic.ui.theme.SonaMusicTheme
import com.akhilesh.sonamusic.viewmodel.AudioPlayerViewModel

/**
 * Sona Music - Audiophile High-Resolution Player
 * Developed by Akhilesh
 */
class MainActivity : ComponentActivity() {

    private val viewModel: AudioPlayerViewModel by viewModels()

    @Suppress("DEPRECATION")
    private fun Intent.usbDevice(): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val device = intent?.usbDevice() ?: return
            val action = intent?.action
            when (action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> viewModel.onUsbDeviceAttached(device)
                UsbManager.ACTION_USB_DEVICE_DETACHED -> viewModel.onUsbDeviceDetached(device)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, usbReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        val irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        viewModel.setConsumerIrManager(irManager)

        setContent {
            val primaryColor by viewModel.dynamicPrimaryColor.collectAsState()
            val secondaryColor by viewModel.dynamicSecondaryColor.collectAsState()

            SonaMusicTheme(primaryColor = primaryColor, secondaryColor = secondaryColor) {
                SonaMusicAppShell(viewModel = viewModel)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
    }
}
