# Sona Music by Akhilesh
Audiophile-grade local audio player for Android.

- UI: Jetpack Compose, glass-style panels, colours follow album art
- Engine: Media3 ExoPlayer in a MediaSessionService, float output, USB DAC detection
- DSP: DynamicsProcessing 10-band EQ + pre-amp, vocal remove/isolate processor
- Hardware: ConsumerIrManager (Bezton remote) + USB-serial IR learning

## Build the APK on GitHub (from a phone)
1. Upload this whole project to a new GitHub repo (make sure `.github/workflows/build.yml` is included).
2. Open the repo > **Actions** > **Build APK** > **Run workflow**.
3. When it turns green, open the run and download **SonaMusic-debug-apk** (a zip containing `app-debug.apk`).
4. Extract, tap the APK, and allow "Install unknown apps".
